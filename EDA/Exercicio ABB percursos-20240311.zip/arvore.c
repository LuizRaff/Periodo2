#include <stdlib.h>
#include <stdio.h>

#include "arvore.h"

struct arvno {
  int info;
  ArvNo* esq;
  ArvNo* dir;
};

ArvNo* cria_no (int v, ArvNo* esq, ArvNo* dir)
{
  ArvNo* p = (ArvNo*)malloc(sizeof(ArvNo));
  if (p != NULL) {
    p->info = v;
    p->esq = esq;
    p->dir = dir;
  }
  return p;
}

void imprime (ArvNo* r)
{
  printf("(");
  if (r != NULL) {
    printf("%d ", r->info);
    imprime(r->esq);
    printf(", ");
    imprime(r->dir);
  }
  printf(")");
}

void libera (ArvNo* r)
{
  if (r != NULL) {
    libera(r->esq);
    libera(r->dir);
    free(r);
  }
}

void pre_ordem (ArvNo* r)
{
  // COMPLETAR 
}

void simetrica (ArvNo* r)
{
  // COMPLETAR
}

void pos_ordem (ArvNo* r)
{
  // COMPLETAR
}

void mostra_crescente (ArvNo* r)
{
  // COMPLETAR
}

void mostra_decrescente (ArvNo* r)
{
  // COMPLETAR
}