
typedef struct arvno ArvNo;

ArvNo* cria_no (int v, ArvNo* esq, ArvNo* dir);
void imprime (ArvNo* r);
void libera (ArvNo* r);

void pre_ordem (ArvNo* r);
void simetrica (ArvNo* r);
void pos_ordem (ArvNo* r);
void mostra_crescente (ArvNo* r);
void mostra_decrescente (ArvNo* r);
