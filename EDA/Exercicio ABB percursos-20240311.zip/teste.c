#include <stdio.h>
#include "arvore.h"

int main() {
  int n;
  ArvNo* b = NULL;
  ArvNo *a1 = cria_no(6, cria_no(2, cria_no(1, NULL, NULL),
                                    cria_no(4, NULL, NULL)
                          ),
                          cria_no(10, NULL,
                                      cria_no(15, NULL, NULL)
                          )
					    );
  ArvNo *a2 = cria_no(7, cria_no(3, cria_no(2, NULL, NULL), 
                                    NULL
                         ),
                         cria_no(15, cria_no(12, NULL, NULL),
                                     cria_no(19, cria_no(18, NULL, NULL), 
									                               NULL)
			                   )
					    );

  printf("Arvore 1:\n");
  imprime(a1);
  printf("\n");

  printf("Preordem: ");
  pre_ordem(a1);
  printf("\n");

  printf("Simetrica: ");
  simetrica(a1);
  printf("\n");

  printf("Posordem: ");
  pos_ordem(a1);
  printf("\n");

  printf("Mostra valores em ordem crescente: ");
  mostra_crescente(a1);
  printf("\n");

  printf("Mostra valores em ordem decrescente: ");
  mostra_decrescente(a1);
  printf("\n");

  printf("Arvore 2:\n");
  imprime(a2);
  printf("\n");

  printf("Preordem: ");
  pre_ordem(a2);
  printf("\n");

  printf("Simetrica: ");
  simetrica(a2);
  printf("\n");

  printf("Posordem: ");
  pos_ordem(a2);
  printf("\n");

  printf("Mostra valores em ordem crescente: ");
  mostra_crescente(a2);
  printf("\n");

  printf("Mostra valores em ordem decrescente: ");
  mostra_decrescente(a2);
  printf("\n");
 
  return 0;
}
  