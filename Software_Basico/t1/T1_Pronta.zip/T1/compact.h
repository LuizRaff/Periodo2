struct Compactadora{
	char simbolo;             
    unsigned int codigo; 
    int tamanho; 
};
void compacta(FILE *arqTexto, FILE *arqBin, struct Compactadora *v);
void descompacta(FILE *arqBin, FILE *arqTexto, struct Compactadora *v);